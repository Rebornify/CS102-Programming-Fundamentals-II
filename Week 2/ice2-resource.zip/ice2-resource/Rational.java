
public class Rational {

}