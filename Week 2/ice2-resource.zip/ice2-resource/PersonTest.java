import java.util.*;
public class PersonTest {
    public static void main(String[] args) {
        System.out.println("Enter details of the first person:");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first name:");
    }
}