// Shape.java
// this is for Q12
public enum Shape {
    RECTANGLE,
    CIRCLE,
    TRIANGLE
}
