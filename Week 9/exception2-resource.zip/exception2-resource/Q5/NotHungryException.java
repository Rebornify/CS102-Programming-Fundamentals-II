public class NotHungryException extends Exception{
    public NotHungryException(String msg) {
        super(msg);
    }
}
