public class VehicleTest {
    public static void main(String[] args) {
        Motocycle motocycle = new Motocycle(13);
        Car car = new Car(12);

        System.out.println(motocycle.toString());
        System.out.println(car.toString());
    }   
}
