public class Motocycle extends Vehicle {
    public Motocycle(double distancePerLiter) {
        super(2, distancePerLiter);
    }
}
